import "./App.css";
import Navbar from "./Components/Navbar/Navbar";
import Shoes from "./Components/Shoes/Shoes";

function App() {
  return <div>
  <Navbar />
  <Shoes />
  </div>;
}

export default App;
